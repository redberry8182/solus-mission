# SOLUS Mission Portal

This is a static portal for the fictional SOLUS: SATURN 22 boarding pass.

## QR-ready URL

After publishing this folder with GitHub Pages, use:

https://YOUR-USERNAME.github.io/solus-mission/pass/AAYUSHI-RAJGURU.html

Replace YOUR-USERNAME with the GitHub account that owns the repository.

## QR payload

The QR should contain the exact HTTPS URL above. Do not use a `data:` URL for the physical pass.

## Publishing

Create a public GitHub repository named `solus-mission`, upload the contents of this folder, then enable GitHub Pages from Settings → Pages and publish the repository. GitHub Pages supports static sites and provides a default `github.io` address.

For a custom domain, configure it in GitHub Pages and then DNS at your domain provider.
